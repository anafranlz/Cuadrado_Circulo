
public class Cuadrado {

	public int ID;
	
	public Cuadrado() {
		ID = 177438;
		//El ID es la longitud de un lado del cuadrado
	}
	
	public double calcularArea()
	{
		return Math.pow(ID, 2);
	}
	
	public double calcularDiagonal()
	{
		return Math.sqrt(2*ID*ID);
	}
	
	public int calcularPerimetro()
	{
		return ID*4;
	}
	
	public void cambiarLongitud(int x)
	{
		ID = x;
	}
}
