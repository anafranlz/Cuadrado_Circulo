
public class Circulo {

	public int ID;
	
		/*public Circulo() {
			ID = 177438;
			//El ID es el radio del circulo
		}*/
	
	public Circulo() {
		this(177438);
	}
	public Circulo(int x) {
		this.ID = x;
	}
	

	public double calcularArea()
	{
		return 3.1416*ID*ID;
	}
	
	public double calcularCircunferencia()
	{
		return 2*3.1416*ID;
	}
	
	public void cambiarRadio(int x)
	{
		ID = x;
	}
	
}
