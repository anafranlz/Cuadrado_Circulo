
public class Programa {

		public static void main(String[] args) {
			
			Cuadrado pan = new Cuadrado();
			
			System.out.println("El area del cuadrado es: "+pan.calcularArea());
			
			System.out.println("El perimetro del cuadrado es: "+pan.calcularPerimetro());
			
			System.out.println("La diagonal del cuadrado es: "+pan.calcularDiagonal());
			
			pan.cambiarLongitud(9);
			System.out.println("El area del cuadrado al cambiar su longitud es: "+pan.calcularArea());
			System.out.println("El perimetro del cuadrado al cambiar su longitud es: "+pan.calcularPerimetro());
			System.out.println("La diagonal del cuadrado al cambiar su longitud es: "+pan.calcularDiagonal());
			
		
			Circulo queso = new Circulo();
		
			System.out.println("\n");
			System.out.println("El area del circulo es: "+queso.calcularArea());
			
			System.out.println("La circunferencia del circulo es: "+queso.calcularCircunferencia());
			
			queso.cambiarRadio(6);;
			System.out.println("El area del cuadrado al cambiar su longitud es: "+queso.calcularArea());
			System.out.println("El perimetro del cuadrado al cambiar su longitud es: "+queso.calcularCircunferencia());
		}
}

